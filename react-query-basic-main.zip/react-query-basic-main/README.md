# React Query - Ejercicio básico

Recuerden descargar el proyecto y luego ejecutar
```
yarn install
o 
npm install
```
