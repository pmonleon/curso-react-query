# React Query - Issues

1. Clonar repositorio
2. Ejecutar ``` yarn install``` o ```npm install```
3. Abrir el URL del proyecto
